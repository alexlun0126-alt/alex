using HutongGames.PlayMaker;
using UnityEngine;

namespace NewHouse;

public class BolsaNewBehaviour : MonoBehaviour
{
	public bool spawneado;

	public int cantidadchuleta;

	private FsmBool m_guiUseBool;

	private void Start()
	{
		((Object)((Component)this).gameObject).name = "Shopping Bag(Clone)";
		((Component)this).gameObject.layer = LayerMask.NameToLayer("Parts");
		((Component)this).gameObject.tag = "PART";
		m_guiUseBool = PlayMakerGlobals.Instance.Variables.FindFsmBool("GUIuse");
	}

	private void Update()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Expected Obj, but got Unknown
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Expected Obj, but got Unknown
		//IL_005d: Expected Obj, but got Unknown
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Expected Obj, but got Unknown
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Expected Obj, but got Unknown
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0189: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bb: Expected Obj, but got Unknown
		//IL_01e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0207: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_0239: Unknown result type (might be due to invalid IL or missing references)
		//IL_023e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0246: Unknown result type (might be due to invalid IL or missing references)
		//IL_024b: Unknown result type (might be due to invalid IL or missing references)
		//IL_025a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0266: Unknown result type (might be due to invalid IL or missing references)
		//IL_028c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0291: Unknown result type (might be due to invalid IL or missing references)
		//IL_0299: Unknown result type (might be due to invalid IL or missing references)
		//IL_029e: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d0: Expected Obj, but got Unknown
		//IL_02fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0300: Unknown result type (might be due to invalid IL or missing references)
		//IL_0308: Unknown result type (might be due to invalid IL or missing references)
		//IL_030d: Unknown result type (might be due to invalid IL or missing references)
		//IL_031c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0328: Unknown result type (might be due to invalid IL or missing references)
		//IL_034e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0353: Unknown result type (might be due to invalid IL or missing references)
		//IL_035b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0360: Unknown result type (might be due to invalid IL or missing references)
		//IL_036f: Unknown result type (might be due to invalid IL or missing references)
		//IL_037b: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0401: Unknown result type (might be due to invalid IL or missing references)
		//IL_0406: Unknown result type (might be due to invalid IL or missing references)
		//IL_0415: Unknown result type (might be due to invalid IL or missing references)
		//IL_0421: Unknown result type (might be due to invalid IL or missing references)
		//IL_042e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0438: Expected Obj, but got Unknown
		//IL_0463: Unknown result type (might be due to invalid IL or missing references)
		//IL_0468: Unknown result type (might be due to invalid IL or missing references)
		//IL_0470: Unknown result type (might be due to invalid IL or missing references)
		//IL_0475: Unknown result type (might be due to invalid IL or missing references)
		//IL_0484: Unknown result type (might be due to invalid IL or missing references)
		//IL_0490: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0509: Unknown result type (might be due to invalid IL or missing references)
		//IL_050e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0516: Unknown result type (might be due to invalid IL or missing references)
		//IL_051b: Unknown result type (might be due to invalid IL or missing references)
		//IL_052a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0536: Unknown result type (might be due to invalid IL or missing references)
		//IL_055c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0561: Unknown result type (might be due to invalid IL or missing references)
		//IL_0569: Unknown result type (might be due to invalid IL or missing references)
		//IL_056e: Unknown result type (might be due to invalid IL or missing references)
		//IL_057d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0589: Unknown result type (might be due to invalid IL or missing references)
		//IL_05af: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_05bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_05dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f3: Expected Obj, but got Unknown
		//IL_061e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0623: Unknown result type (might be due to invalid IL or missing references)
		//IL_062b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0630: Unknown result type (might be due to invalid IL or missing references)
		//IL_063f: Unknown result type (might be due to invalid IL or missing references)
		//IL_064b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0671: Unknown result type (might be due to invalid IL or missing references)
		//IL_0676: Unknown result type (might be due to invalid IL or missing references)
		//IL_067e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0683: Unknown result type (might be due to invalid IL or missing references)
		//IL_0692: Unknown result type (might be due to invalid IL or missing references)
		//IL_069e: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0717: Unknown result type (might be due to invalid IL or missing references)
		//IL_071c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0724: Unknown result type (might be due to invalid IL or missing references)
		//IL_0729: Unknown result type (might be due to invalid IL or missing references)
		//IL_0738: Unknown result type (might be due to invalid IL or missing references)
		//IL_0744: Unknown result type (might be due to invalid IL or missing references)
		//IL_076a: Unknown result type (might be due to invalid IL or missing references)
		//IL_076f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0777: Unknown result type (might be due to invalid IL or missing references)
		//IL_077c: Unknown result type (might be due to invalid IL or missing references)
		//IL_078b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0797: Unknown result type (might be due to invalid IL or missing references)
		//IL_07bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_07cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_07de: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_07f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0801: Expected Obj, but got Unknown
		//IL_082c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0831: Unknown result type (might be due to invalid IL or missing references)
		//IL_0839: Unknown result type (might be due to invalid IL or missing references)
		//IL_083e: Unknown result type (might be due to invalid IL or missing references)
		//IL_084d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0859: Unknown result type (might be due to invalid IL or missing references)
		//IL_087f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0884: Unknown result type (might be due to invalid IL or missing references)
		//IL_088c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0891: Unknown result type (might be due to invalid IL or missing references)
		//IL_08a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_08d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_08d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_08df: Unknown result type (might be due to invalid IL or missing references)
		//IL_08e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_08f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0925: Unknown result type (might be due to invalid IL or missing references)
		//IL_092a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0932: Unknown result type (might be due to invalid IL or missing references)
		//IL_0937: Unknown result type (might be due to invalid IL or missing references)
		//IL_0946: Unknown result type (might be due to invalid IL or missing references)
		//IL_0952: Unknown result type (might be due to invalid IL or missing references)
		//IL_0978: Unknown result type (might be due to invalid IL or missing references)
		//IL_097d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0985: Unknown result type (might be due to invalid IL or missing references)
		//IL_098a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0999: Unknown result type (might be due to invalid IL or missing references)
		//IL_09a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_09cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_09d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_09d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_09dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_09ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_09f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a1e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a23: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a2b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a30: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a3f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a4b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a58: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a62: Expected Obj, but got Unknown
		//IL_0a8d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a92: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a9a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a9f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aae: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aba: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ae0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ae5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0af2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b01: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b0d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b33: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b38: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b40: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b45: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b54: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b60: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b86: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b8b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b93: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b98: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ba7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bb3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bd9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bde: Unknown result type (might be due to invalid IL or missing references)
		//IL_0be6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0beb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bfa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c06: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c2c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c31: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c39: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c3e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c4d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c59: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c7f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c84: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c8c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c91: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ca0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cac: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cd2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cd7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cdf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ce4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cf3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d0c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d16: Expected Obj, but got Unknown
		//IL_0d42: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d47: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d4f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d54: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d63: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d6f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d95: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d9a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0da2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0da7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0db6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dc2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0de8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ded: Unknown result type (might be due to invalid IL or missing references)
		//IL_0df5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dfa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e09: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e15: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e3b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e40: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e48: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e4d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e5c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e68: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e8e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e93: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e9b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ea0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0eaf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ebb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ee1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ee6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0eee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ef3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f02: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f0e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f34: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f39: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f41: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f46: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f55: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f61: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f87: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f8c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f94: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f99: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fa8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fb4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fda: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fdf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fe7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ffb: Unknown result type (might be due to invalid IL or missing references)
		//IL_1007: Unknown result type (might be due to invalid IL or missing references)
		//IL_1014: Unknown result type (might be due to invalid IL or missing references)
		//IL_101e: Expected Obj, but got Unknown
		//IL_104a: Unknown result type (might be due to invalid IL or missing references)
		//IL_104f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1057: Unknown result type (might be due to invalid IL or missing references)
		//IL_105c: Unknown result type (might be due to invalid IL or missing references)
		//IL_106b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1077: Unknown result type (might be due to invalid IL or missing references)
		//IL_109d: Unknown result type (might be due to invalid IL or missing references)
		//IL_10a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_10aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_10af: Unknown result type (might be due to invalid IL or missing references)
		//IL_10be: Unknown result type (might be due to invalid IL or missing references)
		//IL_10ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_10f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_10f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_10fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_1102: Unknown result type (might be due to invalid IL or missing references)
		//IL_1111: Unknown result type (might be due to invalid IL or missing references)
		//IL_111d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1143: Unknown result type (might be due to invalid IL or missing references)
		//IL_1148: Unknown result type (might be due to invalid IL or missing references)
		//IL_1150: Unknown result type (might be due to invalid IL or missing references)
		//IL_1155: Unknown result type (might be due to invalid IL or missing references)
		//IL_1164: Unknown result type (might be due to invalid IL or missing references)
		//IL_1170: Unknown result type (might be due to invalid IL or missing references)
		//IL_1196: Unknown result type (might be due to invalid IL or missing references)
		//IL_119b: Unknown result type (might be due to invalid IL or missing references)
		//IL_11a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_11a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_11b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_11c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_11e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_11ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_11f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_11fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_120a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1216: Unknown result type (might be due to invalid IL or missing references)
		//IL_123c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1241: Unknown result type (might be due to invalid IL or missing references)
		//IL_1249: Unknown result type (might be due to invalid IL or missing references)
		//IL_124e: Unknown result type (might be due to invalid IL or missing references)
		//IL_125d: Unknown result type (might be due to invalid IL or missing references)
		//IL_1269: Unknown result type (might be due to invalid IL or missing references)
		//IL_128f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1294: Unknown result type (might be due to invalid IL or missing references)
		//IL_129c: Unknown result type (might be due to invalid IL or missing references)
		//IL_12a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_12b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_12bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_12e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_12e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_12ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_12f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_1303: Unknown result type (might be due to invalid IL or missing references)
		//IL_130f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1335: Unknown result type (might be due to invalid IL or missing references)
		//IL_133a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1342: Unknown result type (might be due to invalid IL or missing references)
		//IL_1347: Unknown result type (might be due to invalid IL or missing references)
		//IL_1356: Unknown result type (might be due to invalid IL or missing references)
		//IL_1362: Unknown result type (might be due to invalid IL or missing references)
		//IL_136f: Unknown result type (might be due to invalid IL or missing references)
		//IL_1379: Expected Obj, but got Unknown
		RaycastHit val = default;
		if (!((Object)GameObject.Find("PLAYER") != (Object)null) || !Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), ref val, 1f) || !((Object)((Component)val.collider).gameObject == (Object)((Component)this).gameObject))
		{
			return;
		}
		m_guiUseBool.Value = true;
		if (cInput.GetButtonDown("Use"))
		{
			if (cantidadchuleta == 0)
			{
				Object.Destroy((Object)((Component)this).gameObject);
			}
			if (cantidadchuleta == 1)
			{
				FileteBehaviour fileteBehaviour = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position = ((Component)this).transform.position;
				Quaternion rotation = ((Component)this).transform.rotation;
				fileteBehaviour.spawned = true;
				((Component)fileteBehaviour).transform.position = position;
				((Component)fileteBehaviour).transform.rotation = rotation;
				Object.Destroy((Object)((Component)this).gameObject);
			}
			if (cantidadchuleta == 2)
			{
				FileteBehaviour fileteBehaviour2 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position2 = ((Component)this).transform.position;
				Quaternion rotation2 = ((Component)this).transform.rotation;
				fileteBehaviour2.spawned = true;
				((Component)fileteBehaviour2).transform.position = position2;
				((Component)fileteBehaviour2).transform.rotation = rotation2;
				FileteBehaviour fileteBehaviour3 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position3 = ((Component)this).transform.position;
				Quaternion rotation3 = ((Component)this).transform.rotation;
				fileteBehaviour3.spawned = true;
				((Component)fileteBehaviour3).transform.position = position3;
				((Component)fileteBehaviour3).transform.rotation = rotation3;
				Object.Destroy((Object)((Component)this).gameObject);
			}
			if (cantidadchuleta == 3)
			{
				FileteBehaviour fileteBehaviour4 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position4 = ((Component)this).transform.position;
				Quaternion rotation4 = ((Component)this).transform.rotation;
				fileteBehaviour4.spawned = true;
				((Component)fileteBehaviour4).transform.position = position4;
				((Component)fileteBehaviour4).transform.rotation = rotation4;
				FileteBehaviour fileteBehaviour5 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position5 = ((Component)this).transform.position;
				Quaternion rotation5 = ((Component)this).transform.rotation;
				fileteBehaviour5.spawned = true;
				((Component)fileteBehaviour5).transform.position = position5;
				((Component)fileteBehaviour5).transform.rotation = rotation5;
				FileteBehaviour fileteBehaviour6 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position6 = ((Component)this).transform.position;
				Quaternion rotation6 = ((Component)this).transform.rotation;
				fileteBehaviour6.spawned = true;
				((Component)fileteBehaviour6).transform.position = position6;
				((Component)fileteBehaviour6).transform.rotation = rotation6;
				Object.Destroy((Object)((Component)this).gameObject);
			}
			if (cantidadchuleta == 4)
			{
				FileteBehaviour fileteBehaviour7 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position7 = ((Component)this).transform.position;
				Quaternion rotation7 = ((Component)this).transform.rotation;
				fileteBehaviour7.spawned = true;
				((Component)fileteBehaviour7).transform.position = position7;
				((Component)fileteBehaviour7).transform.rotation = rotation7;
				FileteBehaviour fileteBehaviour8 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position8 = ((Component)this).transform.position;
				Quaternion rotation8 = ((Component)this).transform.rotation;
				fileteBehaviour8.spawned = true;
				((Component)fileteBehaviour8).transform.position = position8;
				((Component)fileteBehaviour8).transform.rotation = rotation8;
				FileteBehaviour fileteBehaviour9 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position9 = ((Component)this).transform.position;
				Quaternion rotation9 = ((Component)this).transform.rotation;
				fileteBehaviour9.spawned = true;
				((Component)fileteBehaviour9).transform.position = position9;
				((Component)fileteBehaviour9).transform.rotation = rotation9;
				FileteBehaviour fileteBehaviour10 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position10 = ((Component)this).transform.position;
				Quaternion rotation10 = ((Component)this).transform.rotation;
				fileteBehaviour10.spawned = true;
				((Component)fileteBehaviour10).transform.position = position10;
				((Component)fileteBehaviour10).transform.rotation = rotation10;
				Object.Destroy((Object)((Component)this).gameObject);
			}
			if (cantidadchuleta == 5)
			{
				FileteBehaviour fileteBehaviour11 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position11 = ((Component)this).transform.position;
				Quaternion rotation11 = ((Component)this).transform.rotation;
				fileteBehaviour11.spawned = true;
				((Component)fileteBehaviour11).transform.position = position11;
				((Component)fileteBehaviour11).transform.rotation = rotation11;
				FileteBehaviour fileteBehaviour12 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position12 = ((Component)this).transform.position;
				Quaternion rotation12 = ((Component)this).transform.rotation;
				fileteBehaviour12.spawned = true;
				((Component)fileteBehaviour12).transform.position = position12;
				((Component)fileteBehaviour12).transform.rotation = rotation12;
				FileteBehaviour fileteBehaviour13 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position13 = ((Component)this).transform.position;
				Quaternion rotation13 = ((Component)this).transform.rotation;
				fileteBehaviour13.spawned = true;
				((Component)fileteBehaviour13).transform.position = position13;
				((Component)fileteBehaviour13).transform.rotation = rotation13;
				FileteBehaviour fileteBehaviour14 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position14 = ((Component)this).transform.position;
				Quaternion rotation14 = ((Component)this).transform.rotation;
				fileteBehaviour14.spawned = true;
				((Component)fileteBehaviour14).transform.position = position14;
				((Component)fileteBehaviour14).transform.rotation = rotation14;
				FileteBehaviour fileteBehaviour15 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position15 = ((Component)this).transform.position;
				Quaternion rotation15 = ((Component)this).transform.rotation;
				fileteBehaviour15.spawned = true;
				((Component)fileteBehaviour15).transform.position = position15;
				((Component)fileteBehaviour15).transform.rotation = rotation15;
				Object.Destroy((Object)((Component)this).gameObject);
			}
			if (cantidadchuleta == 6)
			{
				FileteBehaviour fileteBehaviour16 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position16 = ((Component)this).transform.position;
				Quaternion rotation16 = ((Component)this).transform.rotation;
				fileteBehaviour16.spawned = true;
				((Component)fileteBehaviour16).transform.position = position16;
				((Component)fileteBehaviour16).transform.rotation = rotation16;
				FileteBehaviour fileteBehaviour17 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position17 = ((Component)this).transform.position;
				Quaternion rotation17 = ((Component)this).transform.rotation;
				fileteBehaviour17.spawned = true;
				((Component)fileteBehaviour17).transform.position = position17;
				((Component)fileteBehaviour17).transform.rotation = rotation17;
				FileteBehaviour fileteBehaviour18 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position18 = ((Component)this).transform.position;
				Quaternion rotation18 = ((Component)this).transform.rotation;
				fileteBehaviour18.spawned = true;
				((Component)fileteBehaviour18).transform.position = position18;
				((Component)fileteBehaviour18).transform.rotation = rotation18;
				FileteBehaviour fileteBehaviour19 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position19 = ((Component)this).transform.position;
				Quaternion rotation19 = ((Component)this).transform.rotation;
				fileteBehaviour19.spawned = true;
				((Component)fileteBehaviour19).transform.position = position19;
				((Component)fileteBehaviour19).transform.rotation = rotation19;
				FileteBehaviour fileteBehaviour20 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position20 = ((Component)this).transform.position;
				Quaternion rotation20 = ((Component)this).transform.rotation;
				fileteBehaviour20.spawned = true;
				((Component)fileteBehaviour20).transform.position = position20;
				((Component)fileteBehaviour20).transform.rotation = rotation20;
				FileteBehaviour fileteBehaviour21 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position21 = ((Component)this).transform.position;
				Quaternion rotation21 = ((Component)this).transform.rotation;
				fileteBehaviour21.spawned = true;
				((Component)fileteBehaviour21).transform.position = position21;
				((Component)fileteBehaviour21).transform.rotation = rotation21;
				Object.Destroy((Object)((Component)this).gameObject);
			}
			if (cantidadchuleta == 7)
			{
				FileteBehaviour fileteBehaviour22 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position22 = ((Component)this).transform.position;
				Quaternion rotation22 = ((Component)this).transform.rotation;
				fileteBehaviour22.spawned = true;
				((Component)fileteBehaviour22).transform.position = position22;
				((Component)fileteBehaviour22).transform.rotation = rotation22;
				FileteBehaviour fileteBehaviour23 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position23 = ((Component)this).transform.position;
				Quaternion rotation23 = ((Component)this).transform.rotation;
				fileteBehaviour23.spawned = true;
				((Component)fileteBehaviour23).transform.position = position23;
				((Component)fileteBehaviour23).transform.rotation = rotation23;
				FileteBehaviour fileteBehaviour24 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position24 = ((Component)this).transform.position;
				Quaternion rotation24 = ((Component)this).transform.rotation;
				fileteBehaviour24.spawned = true;
				((Component)fileteBehaviour24).transform.position = position24;
				((Component)fileteBehaviour24).transform.rotation = rotation24;
				FileteBehaviour fileteBehaviour25 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position25 = ((Component)this).transform.position;
				Quaternion rotation25 = ((Component)this).transform.rotation;
				fileteBehaviour25.spawned = true;
				((Component)fileteBehaviour25).transform.position = position25;
				((Component)fileteBehaviour25).transform.rotation = rotation25;
				FileteBehaviour fileteBehaviour26 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position26 = ((Component)this).transform.position;
				Quaternion rotation26 = ((Component)this).transform.rotation;
				fileteBehaviour26.spawned = true;
				((Component)fileteBehaviour26).transform.position = position26;
				((Component)fileteBehaviour26).transform.rotation = rotation26;
				FileteBehaviour fileteBehaviour27 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position27 = ((Component)this).transform.position;
				Quaternion rotation27 = ((Component)this).transform.rotation;
				fileteBehaviour27.spawned = true;
				((Component)fileteBehaviour27).transform.position = position27;
				((Component)fileteBehaviour27).transform.rotation = rotation27;
				FileteBehaviour fileteBehaviour28 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position28 = ((Component)this).transform.position;
				Quaternion rotation28 = ((Component)this).transform.rotation;
				fileteBehaviour28.spawned = true;
				((Component)fileteBehaviour28).transform.position = position28;
				((Component)fileteBehaviour28).transform.rotation = rotation28;
				Object.Destroy((Object)((Component)this).gameObject);
			}
			if (cantidadchuleta == 8)
			{
				FileteBehaviour fileteBehaviour29 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position29 = ((Component)this).transform.position;
				Quaternion rotation29 = ((Component)this).transform.rotation;
				fileteBehaviour29.spawned = true;
				((Component)fileteBehaviour29).transform.position = position29;
				((Component)fileteBehaviour29).transform.rotation = rotation29;
				FileteBehaviour fileteBehaviour30 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position30 = ((Component)this).transform.position;
				Quaternion rotation30 = ((Component)this).transform.rotation;
				fileteBehaviour30.spawned = true;
				((Component)fileteBehaviour30).transform.position = position30;
				((Component)fileteBehaviour30).transform.rotation = rotation30;
				FileteBehaviour fileteBehaviour31 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position31 = ((Component)this).transform.position;
				Quaternion rotation31 = ((Component)this).transform.rotation;
				fileteBehaviour31.spawned = true;
				((Component)fileteBehaviour31).transform.position = position31;
				((Component)fileteBehaviour31).transform.rotation = rotation31;
				FileteBehaviour fileteBehaviour32 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position32 = ((Component)this).transform.position;
				Quaternion rotation32 = ((Component)this).transform.rotation;
				fileteBehaviour32.spawned = true;
				((Component)fileteBehaviour32).transform.position = position32;
				((Component)fileteBehaviour32).transform.rotation = rotation32;
				FileteBehaviour fileteBehaviour33 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position33 = ((Component)this).transform.position;
				Quaternion rotation33 = ((Component)this).transform.rotation;
				fileteBehaviour33.spawned = true;
				((Component)fileteBehaviour33).transform.position = position33;
				((Component)fileteBehaviour33).transform.rotation = rotation33;
				FileteBehaviour fileteBehaviour34 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position34 = ((Component)this).transform.position;
				Quaternion rotation34 = ((Component)this).transform.rotation;
				fileteBehaviour34.spawned = true;
				((Component)fileteBehaviour34).transform.position = position34;
				((Component)fileteBehaviour34).transform.rotation = rotation34;
				FileteBehaviour fileteBehaviour35 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position35 = ((Component)this).transform.position;
				Quaternion rotation35 = ((Component)this).transform.rotation;
				fileteBehaviour35.spawned = true;
				((Component)fileteBehaviour35).transform.position = position35;
				((Component)fileteBehaviour35).transform.rotation = rotation35;
				FileteBehaviour fileteBehaviour36 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position36 = ((Component)this).transform.position;
				Quaternion rotation36 = ((Component)this).transform.rotation;
				fileteBehaviour36.spawned = true;
				((Component)fileteBehaviour36).transform.position = position36;
				((Component)fileteBehaviour36).transform.rotation = rotation36;
				Object.Destroy((Object)((Component)this).gameObject);
			}
			if (cantidadchuleta == 9)
			{
				FileteBehaviour fileteBehaviour37 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position37 = ((Component)this).transform.position;
				Quaternion rotation37 = ((Component)this).transform.rotation;
				fileteBehaviour37.spawned = true;
				((Component)fileteBehaviour37).transform.position = position37;
				((Component)fileteBehaviour37).transform.rotation = rotation37;
				FileteBehaviour fileteBehaviour38 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position38 = ((Component)this).transform.position;
				Quaternion rotation38 = ((Component)this).transform.rotation;
				fileteBehaviour38.spawned = true;
				((Component)fileteBehaviour38).transform.position = position38;
				((Component)fileteBehaviour38).transform.rotation = rotation38;
				FileteBehaviour fileteBehaviour39 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position39 = ((Component)this).transform.position;
				Quaternion rotation39 = ((Component)this).transform.rotation;
				fileteBehaviour39.spawned = true;
				((Component)fileteBehaviour39).transform.position = position39;
				((Component)fileteBehaviour39).transform.rotation = rotation39;
				FileteBehaviour fileteBehaviour40 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position40 = ((Component)this).transform.position;
				Quaternion rotation40 = ((Component)this).transform.rotation;
				fileteBehaviour40.spawned = true;
				((Component)fileteBehaviour40).transform.position = position40;
				((Component)fileteBehaviour40).transform.rotation = rotation40;
				FileteBehaviour fileteBehaviour41 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position41 = ((Component)this).transform.position;
				Quaternion rotation41 = ((Component)this).transform.rotation;
				fileteBehaviour41.spawned = true;
				((Component)fileteBehaviour41).transform.position = position41;
				((Component)fileteBehaviour41).transform.rotation = rotation41;
				FileteBehaviour fileteBehaviour42 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position42 = ((Component)this).transform.position;
				Quaternion rotation42 = ((Component)this).transform.rotation;
				fileteBehaviour42.spawned = true;
				((Component)fileteBehaviour42).transform.position = position42;
				((Component)fileteBehaviour42).transform.rotation = rotation42;
				FileteBehaviour fileteBehaviour43 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position43 = ((Component)this).transform.position;
				Quaternion rotation43 = ((Component)this).transform.rotation;
				fileteBehaviour43.spawned = true;
				((Component)fileteBehaviour43).transform.position = position43;
				((Component)fileteBehaviour43).transform.rotation = rotation43;
				FileteBehaviour fileteBehaviour44 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position44 = ((Component)this).transform.position;
				Quaternion rotation44 = ((Component)this).transform.rotation;
				fileteBehaviour44.spawned = true;
				((Component)fileteBehaviour44).transform.position = position44;
				((Component)fileteBehaviour44).transform.rotation = rotation44;
				FileteBehaviour fileteBehaviour45 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position45 = ((Component)this).transform.position;
				Quaternion rotation45 = ((Component)this).transform.rotation;
				fileteBehaviour45.spawned = true;
				((Component)fileteBehaviour45).transform.position = position45;
				((Component)fileteBehaviour45).transform.rotation = rotation45;
				Object.Destroy((Object)((Component)this).gameObject);
			}
			if (cantidadchuleta == 10)
			{
				FileteBehaviour fileteBehaviour46 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position46 = ((Component)this).transform.position;
				Quaternion rotation46 = ((Component)this).transform.rotation;
				fileteBehaviour46.spawned = true;
				((Component)fileteBehaviour46).transform.position = position46;
				((Component)fileteBehaviour46).transform.rotation = rotation46;
				FileteBehaviour fileteBehaviour47 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position47 = ((Component)this).transform.position;
				Quaternion rotation47 = ((Component)this).transform.rotation;
				fileteBehaviour47.spawned = true;
				((Component)fileteBehaviour47).transform.position = position47;
				((Component)fileteBehaviour47).transform.rotation = rotation47;
				FileteBehaviour fileteBehaviour48 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position48 = ((Component)this).transform.position;
				Quaternion rotation48 = ((Component)this).transform.rotation;
				fileteBehaviour48.spawned = true;
				((Component)fileteBehaviour48).transform.position = position48;
				((Component)fileteBehaviour48).transform.rotation = rotation48;
				FileteBehaviour fileteBehaviour49 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position49 = ((Component)this).transform.position;
				Quaternion rotation49 = ((Component)this).transform.rotation;
				fileteBehaviour49.spawned = true;
				((Component)fileteBehaviour49).transform.position = position49;
				((Component)fileteBehaviour49).transform.rotation = rotation49;
				FileteBehaviour fileteBehaviour50 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position50 = ((Component)this).transform.position;
				Quaternion rotation50 = ((Component)this).transform.rotation;
				fileteBehaviour50.spawned = true;
				((Component)fileteBehaviour50).transform.position = position50;
				((Component)fileteBehaviour50).transform.rotation = rotation50;
				FileteBehaviour fileteBehaviour51 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position51 = ((Component)this).transform.position;
				Quaternion rotation51 = ((Component)this).transform.rotation;
				fileteBehaviour51.spawned = true;
				((Component)fileteBehaviour51).transform.position = position51;
				((Component)fileteBehaviour51).transform.rotation = rotation51;
				FileteBehaviour fileteBehaviour52 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position52 = ((Component)this).transform.position;
				Quaternion rotation52 = ((Component)this).transform.rotation;
				fileteBehaviour52.spawned = true;
				((Component)fileteBehaviour52).transform.position = position52;
				((Component)fileteBehaviour52).transform.rotation = rotation52;
				FileteBehaviour fileteBehaviour53 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position53 = ((Component)this).transform.position;
				Quaternion rotation53 = ((Component)this).transform.rotation;
				fileteBehaviour53.spawned = true;
				((Component)fileteBehaviour53).transform.position = position53;
				((Component)fileteBehaviour53).transform.rotation = rotation53;
				FileteBehaviour fileteBehaviour54 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position54 = ((Component)this).transform.position;
				Quaternion rotation54 = ((Component)this).transform.rotation;
				fileteBehaviour54.spawned = true;
				((Component)fileteBehaviour54).transform.position = position54;
				((Component)fileteBehaviour54).transform.rotation = rotation54;
				FileteBehaviour fileteBehaviour55 = Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("chuleta")).AddComponent<FileteBehaviour>();
				Vector3 position55 = ((Component)this).transform.position;
				Quaternion rotation55 = ((Component)this).transform.rotation;
				fileteBehaviour55.spawned = true;
				((Component)fileteBehaviour55).transform.position = position55;
				((Component)fileteBehaviour55).transform.rotation = rotation55;
				Object.Destroy((Object)((Component)this).gameObject);
			}
		}
	}
}
