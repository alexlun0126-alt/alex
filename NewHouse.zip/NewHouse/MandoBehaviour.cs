using System.Collections.Generic;
using HutongGames.PlayMaker;
using MSCLoader;
using UnityEngine;

namespace NewHouse;

public class MandoBehaviour : MonoBehaviour
{
	public class SaveData
	{
		public List<SaveDataList> save = new List<SaveDataList>();
	}

	public class SaveDataList
	{
		public float posX;

		public float posY;

		public float posZ;

		public float rotX;

		public float rotY;

		public float rotZ;
	}

	private Collider botonmando;

	private GameObject receptormando;

	public bool aperturagate;

	private CasaBehaviour general;

	private PuertaBehaviour puertas;

	private FsmBool m_guiUseBool;

	private void Start()
	{
		((Object)((Component)this).gameObject).name = "Remote Control Gate(Clone)";
		((Component)this).gameObject.layer = LayerMask.NameToLayer("Parts");
		((Component)this).gameObject.tag = "PART";
		general = GameObject.Find("caseron(Clone)").GetComponent<CasaBehaviour>();
		receptormando = ((Component)((Component)general).transform.FindChild("receptormando")).gameObject;
		botonmando = ((Component)((Component)this).transform.FindChild("remoto/zer06/botonmando")).GetComponent<Collider>();
		m_guiUseBool = PlayMakerGlobals.Instance.Variables.FindFsmBool("GUIuse");
		puertas = ((Component)((Component)general).transform.FindChild("utiles/puertas")).GetComponent<PuertaBehaviour>();
		Load();
	}

	public void Save()
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Expected Obj, but got Unknown
		if (general.vendido)
		{
			SaveData saveData = new SaveData();
			SaveDataList item = new SaveDataList
			{
				posX = ((Component)this).transform.position.x,
				posY = ((Component)this).transform.position.y,
				posZ = ((Component)this).transform.position.z,
				rotX = ((Component)this).transform.eulerAngles.x,
				rotY = ((Component)this).transform.eulerAngles.y,
				rotZ = ((Component)this).transform.eulerAngles.z
			};
			saveData.save.Add(item);
			SaveLoad.SerializeSaveFile<SaveData>((Mod)(object)NewHouse.Instance, saveData, "NewHouse-remote.save");
		}
	}

	private void Load()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Expected Obj, but got Unknown
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		SaveData saveData = SaveLoad.DeserializeSaveFile<SaveData>((Mod)(object)NewHouse.Instance, "NewHouse-remote.save");
		if (saveData != null)
		{
			((Component)this).transform.position = new Vector3(saveData.save[0].posX, saveData.save[0].posY, saveData.save[0].posZ);
			((Component)this).transform.eulerAngles = new Vector3(saveData.save[0].rotX, saveData.save[0].rotY, saveData.save[0].rotZ);
		}
		else
		{
			((Component)this).transform.localPosition = new Vector3(-2.108005f, 1f, -5.223052f);
		}
	}

	private void Update()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Expected Obj, but got Unknown
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Expected Obj, but got Unknown
		//IL_00e0: Expected Obj, but got Unknown
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Expected Obj, but got Unknown
		//IL_0166: Expected Obj, but got Unknown
		if (!((Object)NewHouseRuntime.Player != (Object)null))
		{
			return;
		}
		if (Input.GetKey((KeyCode)308) && Input.GetKeyDown((KeyCode)114))
		{
			((Component)this).transform.SetParent(((Component)general).transform);
			((Component)this).transform.localPosition = new Vector3(-2.108f, 0.956f, -5.223f);
			((Component)this).transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
		}
		if (!(Vector3.Distance(NewHouseRuntime.Player.transform.position, ((Component)this).transform.root.position) <= 60f))
		{
			return;
		}
		RaycastHit[] mouseHits = NewHouseRuntime.GetMouseHits(1.5f);
		for (int i = 0; i < mouseHits.Length; i++)
		{
			RaycastHit val = mouseHits[i];
			if (!((Object)val.collider == (Object)botonmando))
			{
				continue;
			}
			m_guiUseBool.Value = true;
			if (!cInput.GetButtonDown("Use") || !((Component)general).GetComponent<ElectricidadBehaviour>().electricidadon)
			{
				continue;
			}
			RaycastHit[] array = Physics.SphereCastAll(((Component)this).transform.position, 20f, ((Component)this).transform.forward);
			for (int j = 0; j < array.Length; j++)
			{
				RaycastHit val2 = array[j];
				if ((Object)val2.collider == (Object)receptormando.GetComponent<Collider>())
				{
					aperturagate = !aperturagate;
					puertas.Operapuerta(aperturagate);
				}
			}
		}
	}
}
