using HutongGames.PlayMaker;
using UnityEngine;

namespace NewHouse;

public class CajaNightStandBehaviour : MonoBehaviour
{
	private FsmBool m_guiUseBool;

	private AudioSource audi;

	private AudioClip audiclip;

	private void Start()
	{
		((Object)((Component)this).gameObject).name = "CARDBOARD(Clone)";
		((Component)this).gameObject.layer = LayerMask.NameToLayer("Parts");
		((Component)this).gameObject.tag = "PART";
		m_guiUseBool = PlayMakerGlobals.Instance.Variables.FindFsmBool("GUIuse");
		audi = ((Component)this).GetComponent<AudioSource>();
		audiclip = audi.clip;
	}

	private void Update()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Expected Obj, but got Unknown
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Expected Obj, but got Unknown
		//IL_0077: Expected Obj, but got Unknown
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Expected Obj, but got Unknown
		if (!((Object)NewHouseRuntime.Player != (Object)null) || !(Vector3.Distance(NewHouseRuntime.Player.transform.position, ((Component)this).transform.position) <= 10f))
		{
			return;
		}
		RaycastHit[] mouseHits = NewHouseRuntime.GetMouseHits(1f);
		for (int i = 0; i < mouseHits.Length; i++)
		{
			RaycastHit val = mouseHits[i];
			if ((Object)((Component)val.collider).gameObject == (Object)((Component)this).gameObject)
			{
				m_guiUseBool.Value = true;
				if (cInput.GetButtonDown("Use"))
				{
					((Component)Object.Instantiate<GameObject>(ModBehaviour.m_bundle.LoadAsset<GameObject>("NightStandPrefab")).AddComponent<NightStandBehaviour>()).transform.position = ((Component)this).transform.position;
					AudioSource.PlayClipAtPoint(audiclip, ((Component)this).transform.position, 1f);
					Object.Destroy((Object)((Component)this).gameObject);
				}
			}
		}
	}
}
