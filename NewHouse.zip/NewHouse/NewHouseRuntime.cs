using UnityEngine;

namespace NewHouse;

internal static class NewHouseRuntime
{
	private static GameObject player;

	private static int shortFrame = -1;

	private static int normalFrame = -1;

	private static RaycastHit[] shortHits = new RaycastHit[0];

	private static RaycastHit[] normalHits = new RaycastHit[0];

	private static readonly RaycastHit[] emptyHits = new RaycastHit[0];

	internal static GameObject Player
	{
		get
		{
			if ((Object)(object)player == (Object)null)
			{
				player = GameObject.Find("PLAYER");
			}
			return player;
		}
	}

	internal static RaycastHit[] GetMouseHits(float distance)
	{
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		int frameCount = Time.frameCount;
		if (distance <= 1.01f)
		{
			if (shortFrame != frameCount)
			{
				shortFrame = frameCount;
				Camera main = Camera.main;
				shortHits = (((Object)(object)main != (Object)null) ? Physics.RaycastAll(main.ScreenPointToRay(Input.mousePosition), 1f) : emptyHits);
			}
			return shortHits;
		}
		if (normalFrame != frameCount)
		{
			normalFrame = frameCount;
			Camera main2 = Camera.main;
			normalHits = (((Object)(object)main2 != (Object)null) ? Physics.RaycastAll(main2.ScreenPointToRay(Input.mousePosition), 1.5f) : emptyHits);
		}
		return normalHits;
	}
}
