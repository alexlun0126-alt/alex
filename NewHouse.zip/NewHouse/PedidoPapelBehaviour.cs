using HutongGames.PlayMaker;
using UnityEngine;

namespace NewHouse;

public class PedidoPapelBehaviour : MonoBehaviour
{
	private TextMesh texto;

	public float precio;

	private Collider pedido;

	private FsmBool m_guiUseBool;

	private CompraObjetosBehaviour compras;

	public bool compramesa;

	public bool compramesa2;

	public bool comprasilla;

	public bool comprasilla2;

	public bool comprasofa;

	public bool comprapouf;

	public bool compraalfombra;

	public bool compranightstand;

	private void Start()
	{
		pedido = ((Component)((Component)this).transform.FindChild("pedido")).GetComponent<Collider>();
		texto = ((Component)((Component)this).transform.FindChild("precio")).GetComponent<TextMesh>();
		m_guiUseBool = PlayMakerGlobals.Instance.Variables.FindFsmBool("GUIuse");
		compras = Object.FindObjectOfType<CompraObjetosBehaviour>();
	}

	private void Update()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Expected Obj, but got Unknown
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Expected Obj, but got Unknown
		//IL_00b6: Expected Obj, but got Unknown
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Expected Obj, but got Unknown
		if (!((Object)NewHouseRuntime.Player != (Object)null))
		{
			return;
		}
		texto.text = precio.ToString();
		if (!(Vector3.Distance(NewHouseRuntime.Player.transform.position, ((Component)this).transform.root.position) <= 60f) || !(Vector3.Distance(NewHouseRuntime.Player.transform.position, ((Component)this).transform.position) <= 10f))
		{
			return;
		}
		RaycastHit[] mouseHits = NewHouseRuntime.GetMouseHits(1.5f);
		for (int i = 0; i < mouseHits.Length; i++)
		{
			RaycastHit val = mouseHits[i];
			if ((Object)val.collider == (Object)pedido && FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney").Value >= precio)
			{
				m_guiUseBool.Value = true;
				if (Input.GetMouseButtonDown(0))
				{
					FsmFloat val2 = FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney");
					val2.Value -= precio;
					compras.PedidoPagado(this);
					Object.Destroy((Object)((Component)this).gameObject);
				}
			}
		}
	}
}
